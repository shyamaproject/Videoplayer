﻿namespace Saturn_Video_Player
{
    partial class Saturnvideoplayer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Saturnvideoplayer));
            this.footerpanel = new System.Windows.Forms.Panel();
            this.distance = new System.Windows.Forms.Label();
            this.position = new System.Windows.Forms.Label();
            this.autoplay = new System.Windows.Forms.CheckBox();
            this.volumelabel = new System.Windows.Forms.Label();
            this.PrevButton = new System.Windows.Forms.Button();
            this.NextButton = new System.Windows.Forms.Button();
            this.StopButton = new System.Windows.Forms.Button();
            this.PlayButton = new System.Windows.Forms.Button();
            this.HeaderPanel = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.videopanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.selectall = new System.Windows.Forms.Button();
            this.Clearbutton = new System.Windows.Forms.Button();
            this.Removebutton = new System.Windows.Forms.Button();
            this.OpenFolderbutton = new System.Windows.Forms.Button();
            this.Videolist = new System.Windows.Forms.ListBox();
            this.DurationTimer = new System.Windows.Forms.Timer(this.components);
            this.colorSlider1 = new Baka_MPlayer.Controls.ColorSlider();
            this.listbutton = new AndreasCoroiu.Controls.djshyamaonoffswitch();
            this.Seekbar = new Baka_MPlayer.Controls.ColorSlider();
            this.footerpanel.SuspendLayout();
            this.HeaderPanel.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // footerpanel
            // 
            this.footerpanel.BackColor = System.Drawing.Color.Black;
            this.footerpanel.Controls.Add(this.distance);
            this.footerpanel.Controls.Add(this.position);
            this.footerpanel.Controls.Add(this.autoplay);
            this.footerpanel.Controls.Add(this.volumelabel);
            this.footerpanel.Controls.Add(this.colorSlider1);
            this.footerpanel.Controls.Add(this.PrevButton);
            this.footerpanel.Controls.Add(this.NextButton);
            this.footerpanel.Controls.Add(this.StopButton);
            this.footerpanel.Controls.Add(this.PlayButton);
            this.footerpanel.Controls.Add(this.listbutton);
            this.footerpanel.Controls.Add(this.Seekbar);
            this.footerpanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.footerpanel.Location = new System.Drawing.Point(0, 285);
            this.footerpanel.Name = "footerpanel";
            this.footerpanel.Size = new System.Drawing.Size(444, 67);
            this.footerpanel.TabIndex = 0;
            // 
            // distance
            // 
            this.distance.AutoSize = true;
            this.distance.BackColor = System.Drawing.Color.Transparent;
            this.distance.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.distance.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.distance.Location = new System.Drawing.Point(291, 38);
            this.distance.Name = "distance";
            this.distance.Size = new System.Drawing.Size(39, 13);
            this.distance.TabIndex = 12;
            this.distance.Text = "00:00";
            // 
            // position
            // 
            this.position.AutoSize = true;
            this.position.BackColor = System.Drawing.Color.Transparent;
            this.position.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.position.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.position.Location = new System.Drawing.Point(291, 52);
            this.position.Name = "position";
            this.position.Size = new System.Drawing.Size(39, 13);
            this.position.TabIndex = 11;
            this.position.Text = "00:00";
            // 
            // autoplay
            // 
            this.autoplay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.autoplay.AutoSize = true;
            this.autoplay.BackColor = System.Drawing.Color.Transparent;
            this.autoplay.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.autoplay.Location = new System.Drawing.Point(449, 43);
            this.autoplay.Name = "autoplay";
            this.autoplay.Size = new System.Drawing.Size(61, 17);
            this.autoplay.TabIndex = 10;
            this.autoplay.Text = "Repeat";
            this.autoplay.UseVisualStyleBackColor = false;
            this.autoplay.CheckedChanged += new System.EventHandler(this.autoplay_CheckedChanged);
            // 
            // volumelabel
            // 
            this.volumelabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.volumelabel.AutoSize = true;
            this.volumelabel.BackColor = System.Drawing.Color.Transparent;
            this.volumelabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.volumelabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.volumelabel.Location = new System.Drawing.Point(331, 44);
            this.volumelabel.Name = "volumelabel";
            this.volumelabel.Size = new System.Drawing.Size(33, 13);
            this.volumelabel.TabIndex = 9;
            this.volumelabel.Text = "Vol :";
            // 
            // PrevButton
            // 
            this.PrevButton.BackColor = System.Drawing.Color.Transparent;
            this.PrevButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PrevButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.PrevButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrevButton.ForeColor = System.Drawing.Color.GhostWhite;
            this.PrevButton.Location = new System.Drawing.Point(174, 37);
            this.PrevButton.Name = "PrevButton";
            this.PrevButton.Size = new System.Drawing.Size(57, 27);
            this.PrevButton.TabIndex = 5;
            this.PrevButton.Text = "Prev";
            this.PrevButton.UseVisualStyleBackColor = false;
            this.PrevButton.Click += new System.EventHandler(this.PrevButton_Click);
            // 
            // NextButton
            // 
            this.NextButton.BackColor = System.Drawing.Color.Transparent;
            this.NextButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.NextButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.NextButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NextButton.ForeColor = System.Drawing.Color.GhostWhite;
            this.NextButton.Location = new System.Drawing.Point(117, 37);
            this.NextButton.Name = "NextButton";
            this.NextButton.Size = new System.Drawing.Size(57, 27);
            this.NextButton.TabIndex = 4;
            this.NextButton.Text = "Next";
            this.NextButton.UseVisualStyleBackColor = false;
            this.NextButton.Click += new System.EventHandler(this.NextButton_Click);
            // 
            // StopButton
            // 
            this.StopButton.BackColor = System.Drawing.Color.Transparent;
            this.StopButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.StopButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.StopButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StopButton.ForeColor = System.Drawing.Color.GhostWhite;
            this.StopButton.Location = new System.Drawing.Point(60, 37);
            this.StopButton.Name = "StopButton";
            this.StopButton.Size = new System.Drawing.Size(57, 27);
            this.StopButton.TabIndex = 3;
            this.StopButton.Text = "Stop";
            this.StopButton.UseVisualStyleBackColor = false;
            this.StopButton.Click += new System.EventHandler(this.StopButton_Click);
            // 
            // PlayButton
            // 
            this.PlayButton.BackColor = System.Drawing.Color.Transparent;
            this.PlayButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.PlayButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.PlayButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlayButton.ForeColor = System.Drawing.Color.GhostWhite;
            this.PlayButton.Location = new System.Drawing.Point(3, 37);
            this.PlayButton.Name = "PlayButton";
            this.PlayButton.Size = new System.Drawing.Size(57, 27);
            this.PlayButton.TabIndex = 2;
            this.PlayButton.Text = "Play";
            this.PlayButton.UseVisualStyleBackColor = false;
            this.PlayButton.Click += new System.EventHandler(this.PlayButton_Click);
            // 
            // HeaderPanel
            // 
            this.HeaderPanel.AllowDrop = true;
            this.HeaderPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.HeaderPanel.Controls.Add(this.splitContainer1);
            this.HeaderPanel.Location = new System.Drawing.Point(0, 0);
            this.HeaderPanel.Name = "HeaderPanel";
            this.HeaderPanel.Size = new System.Drawing.Size(444, 288);
            this.HeaderPanel.TabIndex = 1;
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.Color.Black;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.videopanel);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.panel1);
            this.splitContainer1.Panel2.Controls.Add(this.Videolist);
            this.splitContainer1.Size = new System.Drawing.Size(444, 288);
            this.splitContainer1.SplitterDistance = 85;
            this.splitContainer1.TabIndex = 0;
            // 
            // videopanel
            // 
            this.videopanel.AllowDrop = true;
            this.videopanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.videopanel.Location = new System.Drawing.Point(0, 0);
            this.videopanel.Name = "videopanel";
            this.videopanel.Size = new System.Drawing.Size(85, 288);
            this.videopanel.TabIndex = 0;
            this.videopanel.DragDrop += new System.Windows.Forms.DragEventHandler(this.videopanel_DragDrop);
            this.videopanel.DragEnter += new System.Windows.Forms.DragEventHandler(this.videopanel_DragEnter);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.selectall);
            this.panel1.Controls.Add(this.Clearbutton);
            this.panel1.Controls.Add(this.Removebutton);
            this.panel1.Controls.Add(this.OpenFolderbutton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 249);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(355, 39);
            this.panel1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(289, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Djshyama";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // selectall
            // 
            this.selectall.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.selectall.BackColor = System.Drawing.Color.Transparent;
            this.selectall.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.selectall.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.selectall.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectall.ForeColor = System.Drawing.Color.GhostWhite;
            this.selectall.Location = new System.Drawing.Point(195, 7);
            this.selectall.Name = "selectall";
            this.selectall.Size = new System.Drawing.Size(71, 27);
            this.selectall.TabIndex = 13;
            this.selectall.Text = "Select All";
            this.selectall.UseVisualStyleBackColor = false;
            this.selectall.Click += new System.EventHandler(this.selectall_Click);
            // 
            // Clearbutton
            // 
            this.Clearbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Clearbutton.BackColor = System.Drawing.Color.Transparent;
            this.Clearbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Clearbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Clearbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clearbutton.ForeColor = System.Drawing.Color.GhostWhite;
            this.Clearbutton.Location = new System.Drawing.Point(125, 7);
            this.Clearbutton.Name = "Clearbutton";
            this.Clearbutton.Size = new System.Drawing.Size(66, 27);
            this.Clearbutton.TabIndex = 12;
            this.Clearbutton.Text = "Clear";
            this.Clearbutton.UseVisualStyleBackColor = false;
            this.Clearbutton.Click += new System.EventHandler(this.Clearbutton_Click);
            // 
            // Removebutton
            // 
            this.Removebutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Removebutton.BackColor = System.Drawing.Color.Transparent;
            this.Removebutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Removebutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Removebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Removebutton.ForeColor = System.Drawing.Color.GhostWhite;
            this.Removebutton.Location = new System.Drawing.Point(59, 7);
            this.Removebutton.Name = "Removebutton";
            this.Removebutton.Size = new System.Drawing.Size(66, 27);
            this.Removebutton.TabIndex = 11;
            this.Removebutton.Text = "Remove";
            this.Removebutton.UseVisualStyleBackColor = false;
            this.Removebutton.Click += new System.EventHandler(this.Removebutton_Click);
            // 
            // OpenFolderbutton
            // 
            this.OpenFolderbutton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.OpenFolderbutton.BackColor = System.Drawing.Color.Transparent;
            this.OpenFolderbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.OpenFolderbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.OpenFolderbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OpenFolderbutton.ForeColor = System.Drawing.Color.GhostWhite;
            this.OpenFolderbutton.Location = new System.Drawing.Point(2, 7);
            this.OpenFolderbutton.Name = "OpenFolderbutton";
            this.OpenFolderbutton.Size = new System.Drawing.Size(57, 27);
            this.OpenFolderbutton.TabIndex = 10;
            this.OpenFolderbutton.Text = "Open";
            this.OpenFolderbutton.UseVisualStyleBackColor = false;
            this.OpenFolderbutton.Click += new System.EventHandler(this.OpenFolderbutton_Click);
            // 
            // Videolist
            // 
            this.Videolist.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Videolist.FormattingEnabled = true;
            this.Videolist.Location = new System.Drawing.Point(0, 0);
            this.Videolist.Name = "Videolist";
            this.Videolist.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.Videolist.Size = new System.Drawing.Size(353, 251);
            this.Videolist.TabIndex = 0;
            this.Videolist.SelectedIndexChanged += new System.EventHandler(this.Videolist_SelectedIndexChanged);
            this.Videolist.DragDrop += new System.Windows.Forms.DragEventHandler(this.Videolist_DragDrop);
            this.Videolist.DragEnter += new System.Windows.Forms.DragEventHandler(this.Videolist_DragEnter);
            this.Videolist.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Videolist_MouseDoubleClick);
            // 
            // DurationTimer
            // 
            this.DurationTimer.Interval = 1000;
            this.DurationTimer.Tick += new System.EventHandler(this.DurationTimer_Tick);
            // 
            // colorSlider1
            // 
            this.colorSlider1.AllowDrop = true;
            this.colorSlider1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.colorSlider1.BackColor = System.Drawing.Color.Transparent;
            this.colorSlider1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.colorSlider1.BarColor = System.Drawing.Color.GhostWhite;
            this.colorSlider1.BorderRoundRectSize = new System.Drawing.Size(8, 8);
            this.colorSlider1.ElapsedBarColor = System.Drawing.Color.GhostWhite;
            this.colorSlider1.LargeChange = ((uint)(5u));
            this.colorSlider1.Location = new System.Drawing.Point(363, 41);
            this.colorSlider1.Name = "colorSlider1";
            this.colorSlider1.Size = new System.Drawing.Size(76, 20);
            this.colorSlider1.SmallChange = ((uint)(1u));
            this.colorSlider1.TabIndex = 6;
            this.colorSlider1.Text = "colorSlider1";
            this.colorSlider1.ThumbBorderColor = System.Drawing.Color.GhostWhite;
            this.colorSlider1.ThumbFirstColor = System.Drawing.Color.GhostWhite;
            this.colorSlider1.ThumbRoundRectSize = new System.Drawing.Size(8, 8);
            this.colorSlider1.ThumbSecondColor = System.Drawing.Color.GhostWhite;
            this.colorSlider1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.colorSlider1_Scroll);
            // 
            // listbutton
            // 
            this.listbutton.BackColor = System.Drawing.Color.Transparent;
            this.listbutton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.listbutton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.listbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbutton.ForeColor = System.Drawing.Color.GhostWhite;
            this.listbutton.Location = new System.Drawing.Point(231, 37);
            this.listbutton.Name = "listbutton";
            this.listbutton.Size = new System.Drawing.Size(57, 27);
            this.listbutton.TabIndex = 1;
            this.listbutton.Text = "List";
            this.listbutton.TextOff = "List";
            this.listbutton.TextOn = "List";
            this.listbutton.ToggleState = AndreasCoroiu.Controls.djshyamaonoffswitch.ToggleStates.Off;
            this.listbutton.UseVisualStyleBackColor = false;
            this.listbutton.Click += new System.EventHandler(this.listbutton_Click);
            // 
            // Seekbar
            // 
            this.Seekbar.AllowDrop = true;
            this.Seekbar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.Seekbar.BackColor = System.Drawing.Color.Transparent;
            this.Seekbar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Seekbar.BarColor = System.Drawing.Color.GhostWhite;
            this.Seekbar.BorderRoundRectSize = new System.Drawing.Size(8, 8);
            this.Seekbar.ElapsedBarColor = System.Drawing.Color.GhostWhite;
            this.Seekbar.LargeChange = ((uint)(5u));
            this.Seekbar.Location = new System.Drawing.Point(3, 9);
            this.Seekbar.Name = "Seekbar";
            this.Seekbar.Size = new System.Drawing.Size(436, 20);
            this.Seekbar.SmallChange = ((uint)(1u));
            this.Seekbar.TabIndex = 0;
            this.Seekbar.Text = "Seekbar";
            this.Seekbar.ThumbBorderColor = System.Drawing.Color.GhostWhite;
            this.Seekbar.ThumbFirstColor = System.Drawing.Color.GhostWhite;
            this.Seekbar.ThumbRoundRectSize = new System.Drawing.Size(8, 8);
            this.Seekbar.ThumbSecondColor = System.Drawing.Color.GhostWhite;
            this.Seekbar.Value = 0;
            this.Seekbar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Seekbar_MouseUp);
            // 
            // Saturnvideoplayer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 352);
            this.Controls.Add(this.HeaderPanel);
            this.Controls.Add(this.footerpanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Saturnvideoplayer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Saturn Video Player";
            this.Load += new System.EventHandler(this.Saturnvideoplayer_Load);
            this.footerpanel.ResumeLayout(false);
            this.footerpanel.PerformLayout();
            this.HeaderPanel.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel footerpanel;
        private System.Windows.Forms.Panel HeaderPanel;
        private System.Windows.Forms.Button PrevButton;
        private System.Windows.Forms.Button NextButton;
        private System.Windows.Forms.Button StopButton;
        private System.Windows.Forms.Button PlayButton;
        private AndreasCoroiu.Controls.djshyamaonoffswitch listbutton;
        private Baka_MPlayer.Controls.ColorSlider Seekbar;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel videopanel;
        private System.Windows.Forms.ListBox Videolist;
        private System.Windows.Forms.Label volumelabel;
        private Baka_MPlayer.Controls.ColorSlider colorSlider1;
        private System.Windows.Forms.Timer DurationTimer;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button OpenFolderbutton;
        private System.Windows.Forms.Button Removebutton;
        private System.Windows.Forms.Button Clearbutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button selectall;
        private System.Windows.Forms.CheckBox autoplay;
        private System.Windows.Forms.Label position;
        private System.Windows.Forms.Label distance;
    }
}

