﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AxWMPLib;
using Interop.WMPLib;
using System.IO;
using System.Runtime.InteropServices;

namespace Saturn_Video_Player
{
    public partial class Saturnvideoplayer : Form
    {

        #region  constructor, load

        AxWindowsMediaPlayer player;
       
        int Startindex = 0;
        string[] FileName, FilePath;
        Boolean playnext = false;
        
        public Saturnvideoplayer()
        {
            InitializeComponent();
            splitContainer1.Panel2Collapsed = true;
            splitContainer1.Panel2.Hide();
           
            player = new AxWindowsMediaPlayer();
            player.OpenStateChange += new AxWMPLib._WMPOCXEvents_OpenStateChangeEventHandler(player_OpenStateChange);
            player.PlayStateChange += new AxWMPLib._WMPOCXEvents_PlayStateChangeEventHandler(player_PlayStateChange);
            player.PositionChange += new AxWMPLib._WMPOCXEvents_PositionChangeEventHandler(player_PositionChange);
        }

        
        private void Saturnvideoplayer_Load(object sender, EventArgs e)
        {
            
            videopanel.Controls.Add(player);
            player.Dock = DockStyle.Fill;
            player.uiMode = "None";            
            player.settings.autoStart = true;
            player.Width *= 2 ;
            player.Height *= 2;
            player.windowlessVideo = true;
            player.enableContextMenu = false;
            //player.Ctlenabled = false; // full screen
            player.stretchToFit = true;

            Startindex = 0;
            playnext = false;
            stopPlayer();
            

          
            
        }
        #endregion 

        
        #region dragdrop
        private void videopanel_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                FileName = (string[])e.Data.GetData(DataFormats.FileDrop);

                foreach (string item in FileName)
                {
                    string ext = Path.GetExtension(item);

                         if ((ext == ".3gp") || (ext == ".mp4") ||
                            (ext == ".DAT")  || (ext == ".wmv") ||
                            (ext == ".3g2")  || (ext == ".3gp2")||
                             (ext == ".mpeg")|| (ext == ".mpg") ||
                            (ext == ".mov")  || (ext == ".avi") ||
                            (ext == ".wma")  || (ext == ".wmp"))
                                 
                    {
                        player.URL = item;

                       // Videolist.Items.Add(item);
                    }
                    else
                    {
                        MessageBox.Show("This type of file is not Supported !", "Djshyama Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                }


            }

        }

        private void videopanel_DragEnter(object sender, DragEventArgs e)
        {
              e.Effect = DragDropEffects.All;
        }


        private void Videolist_DragDrop(object sender, DragEventArgs e)
        {
            //if (e.Data.GetDataPresent(DataFormats.FileDrop))
            //{
            //    FileName = (string[])e.Data.GetData(DataFormats.FileDrop);

            //    foreach (string item in FileName)
            //    {
            //        string ext = Path.GetExtension(item);

            //        if ((ext == ".3gp") || (ext == ".mp4") ||
            //           (ext == ".DAT") || (ext == ".wmv") ||
            //           (ext == ".3g2") || (ext == ".3gp2") ||
            //            (ext == ".mpeg") || (ext == ".mpg") ||
            //           (ext == ".mov") || (ext == ".avi") ||
            //           (ext == ".wma") || (ext == ".wmp"))
            //        {
            //            player.URL = item;
            //            Videolist.Items.Add(item);
            //        }
            //        else
            //        {
            //            MessageBox.Show("This type of file is not Supported !", "Djshyama Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //        }

            //    }
            //}


        }


        private void Videolist_DragEnter(object sender, DragEventArgs e)
        {
           // e.Effect = DragDropEffects.All;
        }
       
        #endregion


        #region play stop next prew


        public void stopPlayer()
        {
            try
            {
                player.Ctlcontrols.stop();
            }
            catch (COMException comExc)
            {
                int hr = comExc.ErrorCode;
                String Message = String.Format("There was an error.\nHRESULT = {1}\n{2}", hr.ToString(), comExc.Message);
                MessageBox.Show(Message, "COM Exception");
            } 
        }

        public void playfile(int playlistindex)
        {
            try
            {
                if (Videolist.Items.Count <= 0)
                { return; }
                if (playlistindex < 0)
                {
                    return;
                }
                player.settings.autoStart = true;
                player.URL = FilePath[playlistindex];
                player.Ctlcontrols.next();
                player.Ctlcontrols.play();

            }
            catch { }
            
        }


        private void PlayButton_Click(object sender, EventArgs e)
        {

            try
            {
                if (player.playState == WMPPlayState.wmppsPlaying)
                {
                    player.Ctlcontrols.pause();
                    PlayButton.Text = "Pause";
                }
                else
                {
                    player.Ctlcontrols.play();
                    PlayButton.Text = "Play";
                }
            }
            catch(COMException comExc)
            {
                int hr = comExc.ErrorCode; 
                String Message = String.Format("There was an error.\nHRESULT = {1}\n{2}", hr.ToString(), comExc.Message);
                MessageBox.Show(Message, "COM Exception");
            }  
        }
            
            
        

        private void StopButton_Click(object sender, EventArgs e)
        {
            stopPlayer();
        }
        

        private void PrevButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (Startindex > 0)
                {
                    Startindex = Startindex - 1;
                }

                playfile(Startindex);
            }
            catch { }
           

        }
        private void NextButton_Click(object sender, EventArgs e)
        {

            
            try
            {
                if (Startindex == Videolist.Items.Count - 1)
                {
                    Startindex = Videolist.Items.Count - 1;
                }
                else if (Startindex < Videolist.Items.Count)
                {
                    Startindex = Startindex + 1;

                }

                playfile(Startindex);
            }
            catch { }
           
        }

       
    
#endregion


        #region  listviewsplitcoontainer
        private void listbutton_Click(object sender, EventArgs e)
        {
            if (listbutton.ToggleState == AndreasCoroiu.Controls.djshyamaonoffswitch.ToggleStates.Off)
            {
                splitContainer1.Panel1Collapsed = true;
                splitContainer1.Panel2Collapsed = false;
                
            }
            else if (listbutton.ToggleState == AndreasCoroiu.Controls.djshyamaonoffswitch.ToggleStates.On)
            {
                splitContainer1.Panel1Collapsed = false;
                splitContainer1.Panel2Collapsed = true;
            }

        }

        #endregion


        #region timer & playstate & Seekbar

        private void DurationTimer_Tick(object sender, EventArgs e)
        {

            try
            {
                if (playnext == true)
                {
                    playnext = false;
                    playfile(Startindex);

                }


                DurationTimer.Interval = 1000;
                DurationTimer.Start();
                position.Text = player.Ctlcontrols.currentPositionString;
                Seekbar.Value = Convert.ToInt32(player.Ctlcontrols.currentPosition);
            }
            catch { }

        }


        private void player_OpenStateChange(object sender, AxWMPLib._WMPOCXEvents_OpenStateChangeEvent e)
        {

            if (player.playState == Interop.WMPLib.WMPPlayState.wmppsMediaEnded)
            {
                if (Videolist.SelectedIndex < FileName.Length - 1)
                {
                    Videolist.SelectedIndex = Videolist.SelectedIndex + 1;
                }
            }

            if (player.openState == Interop.WMPLib.WMPOpenState.wmposMediaOpen)
            {
                Seekbar.Maximum = (int)player.currentMedia.duration;
                DurationTimer.Start();
                player.Ctlcontrols.currentPosition = Seekbar.Value;
                distance.Text = player.currentMedia.durationString;
                
            }
        }

        private void player_PositionChange(object sender, AxWMPLib._WMPOCXEvents_PositionChangeEvent e)
        {
            if (player.currentMedia.duration != 0)
            position.Text = player.Ctlcontrols.currentPositionString;
            
        }

        private void player_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            int statuschk = e.newState;  // here the Status return the windows Media Player status where the 8 is the Song or Vedio is completed the playing .

            // Now here i check if the song is completed then i Increment to play the next song

            if (statuschk == 8)
            {
                statuschk = e.newState;

                if (Startindex == Videolist.Items.Count - 1)
                {
                    Startindex = 0;
                }
                else if (Startindex >= 0 && Startindex < Videolist.Items.Count - 1)
                {
                    Startindex = Startindex + 1;

                }
                playnext = true;
            }



        }

        private void Seekbar_MouseUp(object sender, MouseEventArgs e)
        {
            try
            {
                if (player.currentMedia.duration != 0)
                    player.Ctlcontrols.currentPosition = Seekbar.Value;
            }
            catch { }
           
        }

        #endregion


        #region volumebar autoplay

        private void colorSlider1_Scroll(object sender, ScrollEventArgs e)
        {
            int vol = colorSlider1.Value;
            player.settings.volume = vol;
        }
        private void autoplay_CheckedChanged(object sender, EventArgs e)
        {

            if (autoplay.CheckState == CheckState.Checked)
            {
                player.settings.setMode("loop", true);
            }
            else if (autoplay.CheckState == CheckState.Unchecked)
            {
                player.settings.setMode("loop", false);
            }
        }
        #endregion


        #region listbox selected items

        private void Videolist_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            Startindex = Videolist.SelectedIndex;
            playfile(Startindex);

        }
        private void Videolist_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                
                player.URL = FilePath[Videolist.SelectedIndex];
                player.Ctlcontrols.play();
            }
            catch { }
           
        }

        #endregion


        #region open folder
        private void OpenFolderbutton_Click(object sender, EventArgs e)
        {
            playnext = false;
            OpenFileDialog opnFileDlg = new OpenFileDialog();
            opnFileDlg.Multiselect = true;

         

            string VideoFormat =
            "3GP Files : (*.3g2;*.3gp2;*.3gp;*.3gpp)  |3g2;*.3gp2;*.3gp;*.3gpp|"  +
            "MP4 Files : (*.mp4)|*.mp4|"                                        +
            "WMV Files : (*.wmv)|*.wmv|"                                        +
            "MPG Files : (*.mpg;*.mpeg)             |*.mpg;*.mpeg|"             +
            "AVI Files : (*.avi)|*.avi|"                                        +
            "WMP Files : (*.wmp)|*.wmp|"                                       +
            "DAT Files : (*.dat)|*.dat|"                                       +
            "VIDEO Files : (*.3gp;*.wmv;*.mp4;*.mpg;*.avi;*.wmp)|*.3gp;*.wmv;*.mp4;*.mpg;*.avi;*.wmp *.*";

            opnFileDlg.Filter = VideoFormat;
            if (opnFileDlg.ShowDialog() == DialogResult.OK)
            {
                FileName = opnFileDlg.SafeFileNames;
                FilePath = opnFileDlg.FileNames;
                for (int i = 0; i <= FileName.Length - 1; i++)
                {
                    Videolist.Items.Add(FileName[i]);
                }


                Startindex = 0;
                playfile(0);
            }
        }

        #endregion 


        #region listbox all control panel
        private void Clearbutton_Click(object sender, EventArgs e)
        {
            Videolist.Items.Clear();
        }

        private void Removebutton_Click(object sender, EventArgs e)
        {
            for (int i = Videolist.SelectedItems.Count - 1; i >= 0; i--)
            {
                Videolist.Items.Remove(Videolist.SelectedItems[i]);
            }
        }

        private void selectall_Click(object sender, EventArgs e)
        {
           // Videolist.SelectionMode = SelectionMode.MultiExtended;
            // listbox property theke kore nibe

            for (int i = 0; i < Videolist.Items.Count; i++)
            {
                Videolist.SetSelected(i, true);
            }
           
        }

        #endregion

       







       
    }
}

